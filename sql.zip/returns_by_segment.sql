-- returns_by_segment.sql
-- Calculates return rate by customer segment

SELECT
    Segment,
    COUNTIF(Returned_Flag = TRUE) AS Returned_Orders,
    COUNT(Order_ID) AS Total_Orders,
    ROUND(COUNTIF(Returned_Flag = TRUE) / COUNT(Order_ID) * 100, 2) AS Return_Rate_Percentage
FROM
    `your_project.your_dataset.ecommerce_transactions`
GROUP BY
    Segment;