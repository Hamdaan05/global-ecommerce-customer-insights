-- customer_summary.sql
-- Creates a summary of customer-level sales and return data

WITH order_summary AS (
    SELECT
        Customer_ID,
        Customer_Name,
        Region,
        Segment,
        COUNT(Order_ID) AS Total_Orders,
        SUM(Sales) AS Total_Sales,
        SUM(Profit) AS Total_Profit,
        AVG(Sales) AS Avg_Order_Value,
        COUNTIF(Returned_Flag = TRUE) > 0 AS Return_Flag
    FROM
        `your_project.your_dataset.ecommerce_transactions`
    GROUP BY
        Customer_ID, Customer_Name, Region, Segment
)
SELECT * FROM order_summary
ORDER BY Total_Profit DESC;