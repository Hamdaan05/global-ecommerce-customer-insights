-- top_customers_by_profit.sql
-- Fetches the top 10 customers by total profit

SELECT
    Customer_ID,
    Customer_Name,
    SUM(Profit) AS Total_Profit
FROM
    `your_project.your_dataset.ecommerce_transactions`
GROUP BY
    Customer_ID, Customer_Name
ORDER BY
    Total_Profit DESC
LIMIT 10;